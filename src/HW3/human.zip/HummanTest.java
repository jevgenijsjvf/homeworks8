package HW3;


public class HummanTest {

    public static void main(String[] args) {

        Humman humman = new Humman();
        humman.setAge(20);
        humman.name("Ivan");
        //humman.setName
        System.out.println("I'm " + humman.getAge() + "years old");



                 }
}
