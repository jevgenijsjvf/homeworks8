package HW3;

public class Humman {
    private int age;
    private String name;

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void name(String name) {
       System.out.print("Hi! My name is " + name + ",");
    }
    //System.out.println ()
}
