package HW3;


public class HummanTest {

    public static void main(String[] args) {

        Humman humman = new Humman();
        humman.setAge(20);
        humman.setName("Ivan");
        sayHi(humman);
        }
        
    public static void sayHi (Humman humman){
        System.out.println("Hi! My name is " + humman.getName() + " I'm " + humman.getAge() + " years old.");
    }
}
