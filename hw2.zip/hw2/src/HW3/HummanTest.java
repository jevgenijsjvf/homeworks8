package HW3;


public class HummanTest {

    public static void main(String[] args) {

        Humman humman = new Humman();
        humman.setAge(20);
        humman.setName("Ivan");
        humman.sayHi();
        }

}
