package HW4;

public class PhraseAnalyser {
    String str; // ="Make education great again";
    public String getStr()   {

        return str;
    }

    public void setStr(String str){
        this.str = str;
    }

    public String analyser(String phrase){
        String startOfString = "Make";
        String endOfString = "great again";

        boolean resStart= str.startsWith(startOfString);
        boolean resEnd = str.endsWith(endOfString);

    if (resStart&&resEnd) {
        return "It stands no chance..";
    }else if (resStart||resEnd) {
        return "It could be worse";
    }else {
        return "It is fine, really";
    }
}
}
