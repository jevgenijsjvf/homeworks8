package HW4;

public class PhraseAnalyserTest {
    public static void main(String[] args) {
        PhraseAnalyserTest testRunner = new PhraseAnalyserTest();
        testRunner.test1();
        testRunner.test2();
        testRunner.test3();
    }

    public void test1() {
        PhraseAnalyser victim = new PhraseAnalyser();
        String expectedResult = "It stands no chance..";
        victim.setStr("Make education great again");
        String actualResult = victim.analyser("Make education great again");
        if (expectedResult==actualResult) {
            System.out.println(victim.getStr()+": " + expectedResult);
            System.out.println();
        } else {
            System.out.println("Test 1 has failed");
            System.out.println("Expected result: " + expectedResult + " but was: " + victim.getStr());
            System.out.println();
        }
    }

    public void test2() {
        PhraseAnalyser victim = new PhraseAnalyser();
        String expectedResult = "It could be worse";
        victim.setStr("Make education great again good");
        String actualResult = victim.analyser("Make education great again");
        if (expectedResult==actualResult) {
            System.out.println(victim.getStr()+": " + expectedResult);
            System.out.println();
        } else {
            System.out.println("Test 1 has failed");
            System.out.println("Expected result: " + expectedResult + " but was: " + victim.getStr());
            System.out.println();
        }
    }

    public void test3() {
        PhraseAnalyser victim = new PhraseAnalyser();
        String expectedResult = "It is fine, really";
        victim.setStr("I Make education great agains");
        String actualResult = victim.analyser("Make education great again");
        if (expectedResult==actualResult) {
            System.out.println(victim.getStr()+": " + expectedResult);
            System.out.println();
        } else {
            System.out.println("Test 1 has failed");
            System.out.println("Expected result: " + expectedResult + " but was: " + victim.getStr());
            System.out.println();
        }
    }
}
