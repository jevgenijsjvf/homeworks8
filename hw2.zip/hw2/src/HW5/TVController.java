package HW5;

public class TVController {

 private TV tv;

    public TVController(TV tv) {
        this.tv = tv;
    }

    public void turnON () {
        if (tv.isConnect()) {tv.turnON();
        }else System.out.println("TV Controller is not connected!");

    }

    public void turnOff () {
        if (tv.isConnect()) {tv.turnOff();
    }else System.out.println("TV Controller is not connected!");

    }

    public void nextChannel(){
        if (tv.isConnect()) {tv.nextChannel();
        }else System.out.println("TV Controller is not connected!");
    }

    public void previousChannel(){
        if (tv.isConnect()) {tv.previousChannel();
        }else System.out.println("TV Controller is not connected!");
    }

    public void increaseVolume(){
        if (tv.isConnect()) {tv.increaseVolume();
        }else System.out.println("TV Controller is not connected!");
    }

    public void decreaseVolume(){
        if (tv.isConnect()) {tv.decreaseVolume();
        }else System.out.println("TV Controller is not connected!");}
}
