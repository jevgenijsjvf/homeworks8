package ourLesson;

public class SquareCalculator {
    public int calculatorSquare(int number) {
        int squareResult = number * number;
        return squareResult;
    }
}
