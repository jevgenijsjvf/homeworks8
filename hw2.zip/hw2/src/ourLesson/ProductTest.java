package ourLesson;

public class ProductTest {
    public static void main(String[] acts) {
        Product product = new Product();
        product.name = "Coca Cola";
        product.regularPrice = 0.8;
        product.discount = 20;
        product.printInformation(product);

    }


}


