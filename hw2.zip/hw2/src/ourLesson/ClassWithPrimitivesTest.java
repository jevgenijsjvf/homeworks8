package ourLesson;

public class ClassWithPrimitivesTest {
    public static void main(String[] args){
       ClassWithPrimitives classWithPrimitives = new ClassWithPrimitives();
       classWithPrimitives.printToCOnsole();
    }
}
