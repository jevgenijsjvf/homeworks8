package ourLesson;

public class CircleTest {
    public static void main (String[] args) {
        Circle circle = new Circle();
        circle.radius = 5;
        System.out.println("Circle area = " + circle.calculatorArea());
    }
}
