package ourLesson;

public class ClassWithObject {
    Byte byteVariable;
    Short shortVariable;
    Integer integerVariable;
    Long longVariable;
    Float floatVariable;
    Double doubleVariable;
    Character characterVariable;
    Boolean booleanVariable;
}
