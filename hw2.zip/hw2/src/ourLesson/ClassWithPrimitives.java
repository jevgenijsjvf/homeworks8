package ourLesson;

public class ClassWithPrimitives {
    byte byteNumber;
    short shortNumber;
    int intNumber;
    long longNumber;
    char character;
    float floatNumber;
    double doubleNumber;
    boolean aBoolean;
    public void printToCOnsole() {
        System.out.println("byte number = " + byteNumber);
        System.out.println("short number = " + shortNumber);
        System.out.println("int number = " + intNumber);
        System.out.println("long number = " + longNumber);
        System.out.println("character = " + character);
        System.out.println("float number = " + floatNumber);
        System.out.println("double number = " + doubleNumber);
        System.out.println("boolean = " + aBoolean);
    }
}
