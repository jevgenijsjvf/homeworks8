package HW6;

public class FOR {
}
