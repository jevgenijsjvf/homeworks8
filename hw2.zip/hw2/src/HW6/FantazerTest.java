package HW6;

public class FantazerTest {
    public static void main(String[] args) {
        Fantazer run = new Fantazer();
        run.userEnteredNumber(99);
        run.pcEnteredNumber();
        run.compare();

    }
}
